#!/bin/bash

# to be run from ..
# this script just exists to tell you how you'd make openblas- we actually did it via Makefile rules,
# but it's not a default target.

make openblas
