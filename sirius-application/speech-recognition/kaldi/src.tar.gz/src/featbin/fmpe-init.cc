// featbin/fmpe-init.cc

// Copyright 2012  Johns Hopkins University (Author: Daniel Povey)  Yanmin Qian

// See ../../COPYING for clarification regarding multiple authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
// THIS CODE IS PROVIDED *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
// WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
// MERCHANTABLITY OR NON-INFRINGEMENT.
// See the Apache 2 License for the specific language governing permissions and
// limitations under the License.

#include "base/kaldi-common.h"
#include "util/common-utils.h"
#include "transform/fmpe.h"

int main(int argc, char *argv[]) {
  using namespace kaldi;
  try {
    const char *usage =
        "Initialize fMPE transform (to zero)\n"
        "Usage: fmpe-init [options...] <diag-gmm-in> <fmpe-out>\n"
        "E.g. fmpe-init 1.ubm 1.fmpe\n";

    ParseOptions po(usage);
    FmpeOptions opts;
    bool binary = true;
    po.Register("binary", &binary, "If true, output fMPE object in binary mode.");
    opts.Register(&po);
    po.Read(argc, argv);

    if (po.NumArgs() != 2) {
      po.PrintUsage();
      exit(1);
    }

    std::string dgmm_rxfilename = po.GetArg(1),
        fmpe_wxfilename = po.GetArg(2);

    DiagGmm dgmm;
    ReadKaldiObject(dgmm_rxfilename, &dgmm);
    
    
    Fmpe fmpe(dgmm, opts);

    Output ko(fmpe_wxfilename, binary);
    fmpe.Write(ko.Stream(), binary);

    KALDI_LOG << "Initialized fMPE object and wrote to "
              << fmpe_wxfilename;
    return 0;
  } catch(const std::exception &e) {
    std::cerr << e.what();
    return -1;
  }
}
